# Salary Data Processing Assignment

## Overview
This project utilizes Python and R to process employee salary data, encompassing data import, dictionary processing, error handling, CSV export, and zip file management.

## How to Use

### Python (Jupyter Notebook)
1. Open `employee_notebook.ipynb`.
2. Run all cells to:
   - Load salary data
   - Search for employee details
   - Export to CSV and zip

### R (Jupyter Notebook)
1. Open `Rscript_unzip.ipynb`
2. Run all cells to extract and display the CSV file.

## Files
- `Total.csv`: Provided Dataset
- `employee_notebook.ipynb`: Main notebook
- `EmployeeProfile.zip`: Output folder
- `Rscript_unzip.ipynb`: R script


